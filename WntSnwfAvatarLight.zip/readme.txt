---CN 中文---
作者：Wnt. Snwf.
此为免费插件，不得非法售卖

一个简单的大范围光源插件
您可以将.prefab文件直接拖到您的Avatar中以装载
*本插件基于Modular Avatar制作，请确保您安装了MA插件！！！
**允许修改菜单内文字内容，但 *请不要* 修改.prefab文件的名称，否则插件将失效！！！

若无法找到光源菜单，请进行如下操作：
在左边资产栏点击Light，随后在右边编辑栏的“MA Menu Installer”中，选择您安装光源菜单的目标菜单

感谢您的使用！

---EN English---
Author: Wnt. Snwf.
This is a free plugin and must not be sold illegally.

A simple large-area light source plugin.
You can drag the .prefab file directly into your Avatar to load it.
*This plugin is made based on Modular Avatar, please make sure you have installed the MA plugin!!!
**You are allowed to modify text content within the menu, but *please do not* change the name of the .prefab file, otherwise the plugin will not work!!!

If you cannot find the light source menu, please follow these steps:
Click Light in the left asset panel, then in the right edit panel under "MA Menu Installer", select the target menu where you installed the light source menu.

Thank you for using it!

---JP 日本語---
作者：Wnt. Snwf.
これは無料のプラグインであり、違法に販売してはいけません

シンプルな広範囲光源プラグインです
.prefabファイルを直接あなたのAvatarにドラッグして装着できます
*このプラグインはModular Avatarを基に作成されていますので、必ずMAプラグインをインストールしてください！！！
**メニュー内のテキスト内容の変更は許可されていますが、*どうか* .prefabファイルの名前は変更しないでください。変更するとプラグインが無効になります！！！

光源メニューが見つからない場合は、以下の操作を行ってください：
左側のアセットバーでLightをクリックし、その後右側の編集バーの「MA Menu Installer」で、インストールした光源メニューの対象メニューを選択してください

ご利用ありがとうございます！